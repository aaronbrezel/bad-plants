# bad-plants
Website for learning about poisonous plants. Final project for User Interface Design, COMS 4170
